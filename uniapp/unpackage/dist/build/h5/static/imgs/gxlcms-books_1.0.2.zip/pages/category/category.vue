<template>
<view class="main">
	<view class="sex_choose">
		<view :class="'male ' + male_select" @tap="male_tap">男生</view>
		<view :class="'female ' + female_select" @tap="female_tap">女生</view>
		<view :class="'cover ' + cover"></view>
	</view>

	<view class="cat">
		<scroll-view class="cates" scroll-y>
			<view class="cat_cover" :style="'top:' + top + 'rpx;'">{{cat_name}}</view>
			<view v-for="(item, index) in cats_info" :key="index" :data-index="index" class="cat_item" @tap="showSubCats">
				{{item.ltype_name}}
			</view>

		</scroll-view>
		<scroll-view class="subCates" scroll-y>
			<view class="sub_item" data-id="-1" data-name="全部" @tap="toCatInfo">全部</view>
			<view v-for="(item, index) in sub_cats" :key="index" :data-id="item.stype_id" :data-name="item.stype_name" class="sub_item" @tap="toCatInfo">
				{{item.stype_name}}
			</view>
		</scroll-view>
	</view>
</view>
</template>

<script>
/*
* @File:   category.js
* @Author: Gxlcms
* @Email:  2010409646@qq.com
* @Last Modified by:   Gxlcms
* @Comment:
*/
import CategoryRequest from "../../requests/CategoryRequest";
var app = getApp();
var categoryRequest = new CategoryRequest();

export default {
  data() {
    return {
      male_select: "male_select",
      female_select: "",
      press_select: "",
      cover: "cover_male",
      cats_info: [],
      ltype_id: 0,
      sub_cats: [],
      cat_name: "",
      sex: 1,
      // 1男 2女
      top: 0,
      user: ""
    };
  },

  components: {},
  props: {},
  onLoad: function () {
    uni.showLoading({
      "title": "加载中...",
      "duration": 20000
    });
    var user = uni.getStorageSync("user");
    this.setData({
      user
    });
    this.getCats();
  },
  methods: {
    /**
     * 获取分类
     */
    getCats: function () {
      var that = this;
      categoryRequest.getCategories(this.sex, this.user, res => {
        that.setData({
          cats_info: res.data.data,
          cat_name: res.data.data[0].ltype_name,
          sub_cats: res.data.data[0].ltype_list,
          ltype_id: res.data.data[0].ltype_id
        });
        uni.hideLoading();
      });
    },

    /**
     * 选择男生
     */
    male_tap: function () {
      if (this.sex != 1) {
        this.setData({
          male_select: "male_select",
          female_select: "",
          press_select: "",
          cover: "cover_male",
          top: 0,
          sex: 1
        });
        this.getCats();
      }
    },

    /**
     * 选择女生
     */
    female_tap: function () {
      if (this.sex != 2) {
        this.setData({
          male_select: "",
          female_select: "female_select",
          press_select: "",
          cover: "cover_female",
          top: 0,
          sex: 2
        });
        this.getCats();
      }
    },

    /**
     * 二级分类
     */
    showSubCats: function (e) {
      var cat_index = e.target.dataset.index;
      this.setData({
        top: 100 * cat_index,
        cat_name: this.cats_info[cat_index].ltype_name,
        sub_cats: this.cats_info[cat_index].ltype_list,
        ltype_id: this.cats_info[cat_index].ltype_id
      });
    },

    /**
     * 跳转到分类详情页
     */
    toCatInfo: function (e) {
      var sex = this.sex;
      var stype_id = e.target.dataset.id;
      var ltype_id = this.ltype_id;
      var type_name = this.cat_name + ' ' + e.target.dataset.name;
      uni.navigateTo({
        url: `/pages/catedetail/catedetail?sex=${sex}&ltype=${ltype_id}&stype=${stype_id}&title=${type_name}`
      });
    }
  }
};
</script>
<style>
@import "./category.css";
</style>