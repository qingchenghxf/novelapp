<template>
<view>
<scroll-view class="main" :scroll-y="scroll_sta" enable-back-to-top lower-threshold="150" @scrolltolower="showMore" @touchstart="removeTips">
	<!-- 搜索框 -->
	<view :class="search_style" data-id="search">
	  <input class="search_input" type="text" placeholder="搜索" :value="last_keyword" confirm-type="search" @input="autoComplete" @confirm="search" @focus="autoComplete" data-id="search"></input>
	  <image class="search_button" src="/static/imgs/search_button.png" @tap="search" data-id="search"></image>
	  <scroll-view :class="auto_complete_box" v-if="keywords.length>0" scroll-y data-id="search">
	  	<view v-for="(item, index) in keywords" :key="index" class="auto_complete_line" @tap.stop="selectedKeyword" :data-index="index" data-id="search"><image src="/static/imgs/search.png"></image><text>{{item}}</text></view>
	  </scroll-view>
	</view>

	<!-- 轮播图 -->
	<swiper indicator-dots indicator-active-color="#008B8B" autoplay circular class="swiper">
	  <swiper-item v-for="(item, index) in banner" :key="index" :data-book="item.info" :alt="item.title" @tap="toBookInfo"><image :src="item.image"></image></swiper-item>
	</swiper>

	<!-- 推荐书 -->
	<view class="recommend">
		<view :class="recommend_cat_style">
			<view :class="recommend_cat_selected[0]" @tap="selectMale">男生推荐</view>
			<view :class="recommend_cat_selected[1]" @tap="selectFemale">女生推荐</view>
		</view>
		<navigator v-for="(item, index) in now_rank" :key="index" v-if="index<show_num*4" :url="'/pages/bookinfo/bookinfo?book=' + item.book_id" class="book">
			<image :src="item.image" lazy-load></image>
			<view class="book_info">
				<text class="title">{{item.name}}</text>
				<text class="author">作者：{{item.author}}　|　类别：{{item.ltype}}　{{item.stype}}</text>
				<text class="intro">简介：{{item.remark}}</text>
				<view class="follower_outter"><text class="follower_inner">{{item.last_chapter}}</text></view>
			</view>
		</navigator>
    <view class="loading">加载中...</view>
	</view>
</scroll-view>
</view>
</template>

<script>
import IndexRequest from "../../requests/IndexRequest";
var app = getApp();
var request = new IndexRequest();

export default {
  data() { 
    return {
      scroll_sta: true,
      // 滑动
      search_style: "search",
      recommend_cat_style: "recommend_cat",
      // 选择
      recommend_cat_selected: {
        0: "recommend_cat_selected",
        1: ""
      },
      recommend_cat_selected_flag: 1,
      // request获取数据
      male_rank: [],
      female_rank: [],
      request_flag: 0,
      // 当前显示
      now_rank: [],
      show_num: 1,
      banner: [],
      // 搜索自动补全
      keyword: "",
      keywords: {},
      last_keyword: "",
      auto_complete_box: "auto_complete_box auto_complete_box_hidden",
      // 用户TOKEN
      token: "",
      userId: 0
    };
  },

  components: {},
  props: {},
  onLoad: function () {
    // console.log(app.config);
    uni.showLoading({
      "title": "加载中...",
      "duration": 20000
    });
    var user = uni.getStorageSync('user');

    if (!user) {
      var that = this; // 获取Token

      request.getToken(res => {
        var userInfo = {
          token: res.data.data.token,
          userId: res.data.data.user_id
        };
        that.setData({
          request_flag: ++that.request_flag,
          ...userInfo
        });
        uni.setStorage({
          key: 'user',
          data: userInfo
        });
        that.getRandomBooks(1, 4);
        that.getRandomBooks(2, 4);
        that.getBanner(4);
        if (that.request_flag == 4) uni.hideLoading();
      });
    } else {
      this.setData(user);
      this.getRandomBooks(1, 3);
      this.getRandomBooks(2, 3);
      this.getBanner(3);
    }
  },

  /**
   * 转发
   */
  onShareAppMessage: function () {
    return {
      title: '阅鼑(Reading)',
      path: '/pages/index/index',
      success: function (res) {
        // 转发成功
        uni.showToast({
          title: "转发成功",
          icon: "success"
        });
      }
    };
  },
  methods: {
    /**
     * 获取Banner图
     */
    getBanner: function (times) {
      var that = this;
      request.getBanner({
        token: this.token,
        userId: this.userId
      }, res => {
        that.setData({
          banner: res.data.data.banner,
          request_flag: ++that.request_flag
        });
        if (that.request_flag >= times) uni.hideLoading();
      });
    },

    /**
     * 获取随机书
     */
    getRandomBooks: function (maleType = 1, times) {
      var that = this;
      request.getRandomBooks(maleType, {
        token: this.token,
        userId: this.userId
      }, res => {
        if (maleType == 1) {
          var data = {
            male_rank: that.male_rank.concat(res.data.data),
            request_flag: ++that.request_flag
          };

          if (that.recommend_cat_selected_flag == 1) {
            data = {
              now_rank: that.male_rank.concat(res.data.data),
              ...data
            };
          }

          that.setData(data);
        } else {
          var data = {
            female_rank: that.female_rank.concat(res.data.data),
            request_flag: ++that.request_flag
          };

          if (that.recommend_cat_selected_flag == 2) {
            data = {
              now_rank: that.female_rank.concat(res.data.data),
              ...data
            };
          }

          that.setData(data);
        }

        if (that.request_flag >= times) uni.hideLoading();
      });
    },

    /**
     * 跳转到书籍详情
     */
    toBookInfo: function (event) {
      // console.log(event.currentTarget.dataset.book);
      var book = event.currentTarget.dataset.book;
      uni.navigateTo({
        url: "../bookinfo/bookinfo?book=" + book
      });
    },

    /**
     * 搜索自动补全
     */
    autoComplete: function (event) {
      var that = this;
      that.setData({
        keyword: event.detail.value
      });
      var key = encodeURI(event.detail.value);

      if (key == "") {
        request.getHotWords({
          token: this.token,
          userId: this.userId
        }, res => {
          that.setData({
            keywords: res.data.data,
            auto_complete_box: "auto_complete_box auto_complete_box_height"
          });
        });
      } else {
        request.getAutoComplete(key, {
          token: this.token,
          userId: this.userId
        }, res => {
          var words = res.data.data.map(item => item.name);

          if (words.length > 5) {
            that.setData({
              keywords: words,
              auto_complete_box: "auto_complete_box auto_complete_box_height"
            });
          } else {
            that.setData({
              keywords: words,
              auto_complete_box: "auto_complete_box"
            });
          }
        });
      }
    },

    /**
     * 选择词条
     */
    selectedKeyword: function (event) {
      var keyword_index = event.currentTarget.dataset.index;
      this.setData({
        last_keyword: this.keywords[keyword_index]
      });
      uni.navigateTo({
        url: "/pages/searchRes/searchRes?keyword=" + this.keywords[keyword_index]
      });
    },

    /**
     * 点击搜索按钮
     */
    search: function () {
      var keyword = this.keyword;

      if (keyword != "") {
        uni.navigateTo({
          url: "/pages/searchRes/searchRes?keyword=" + keyword
        });
      }
    },

    /**
     * 移除搜索提示
     */
    removeTips: function (event) {
      if (event.target.dataset.id != "search") {
        this.setData({
          scroll_sta: true,
          auto_complete_box: this.auto_complete_box + " auto_complete_box_hidden"
        });
      } else {
        this.setData({
          scroll_sta: false
        });
      }
    },
    // changeStyle: function(event){
    // 	if(event.detail.scrollTop >= 190) {
    // 		this.setData({
    // 			// search_style: "search search_fixed",
    // 			recommend_cat_style: "recommend_cat recommend_cat_fixed"
    // 		});
    // 	}else if(event.detail.scrollTop < 190){
    // 		this.setData({
    // 			// search_style: "search",
    // 			recommend_cat_style: "recommend_cat"
    // 		});
    // 	}
    // },

    /**
     * 选择男生
     */
    selectMale: function () {
      if (this.recommend_cat_selected_flag != 1) {
        this.setData({
          recommend_cat_selected: {
            0: "recommend_cat_selected",
            1: ""
          },
          recommend_cat_selected_flag: 1,
          now_rank: this.male_rank
        });
      }
    },

    /**
     * 选择女生
     */
    selectFemale: function () {
      if (this.recommend_cat_selected_flag != 2) {
        this.setData({
          recommend_cat_selected: {
            0: "",
            1: "recommend_cat_selected"
          },
          recommend_cat_selected_flag: 2,
          now_rank: this.female_rank
        });
      }
    },

    /**
     * 下拉更多
     */
    showMore: function () {
		console.log(this.recommend_cat_selected_flag)
      this.getRandomBooks(this.recommend_cat_selected_flag);
      this.setData({
        show_num: this.show_num + 1
      });
    }
  }
};
</script>
<style>
@import "./index.css";
</style>