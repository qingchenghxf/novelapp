<template>
<view class="main">
	<scroll-view class="cat_books" scroll-y>
		
		<view class="loading">开发中...</view>
	</scroll-view>
</view>
</template>

<script>
/*
* @File:   catedetail.js
* @Author: Gxlcms
* @Email:  2010409646@qq.com
* @Last Modified by:   Gxlcms
* @Comment:
*/


export default {
  data() {
    return {
      cat_books: [],
      sex: 1,
      ltype: -1,
      stype: -1,
      page: 1,
      user: {}
    };
  },

  components: {},
  props: {},
  onLoad: function (opt) {
  
  },
  methods: {
  
  }
};
</script>
<style>
@import "./catedetail.css";
</style>