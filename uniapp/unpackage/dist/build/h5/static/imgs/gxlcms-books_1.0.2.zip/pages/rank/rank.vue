<template>
<view class="main">
	<view class="sex_choose">
		<view :class="'male ' + male_select" @tap="male_tap">男生</view>
		<view :class="'female ' + female_select" @tap="female_tap">女生</view>
		<view :class="'cover ' + cover"></view>
	</view>
	<scroll-view class="rank_cate" scroll-y>
		<navigator v-for="(item, index) in rank_categories" :key="index" :url="'/pages/rankdetail/rankdetail?rank_id=' + item.name + '&title=' + item.title" class="rank_item">
			<image :src="item.icon"></image>
			<view class="rank_title">{{item.title}}</view>
		</navigator>
	</scroll-view>
</view>
</template>

<script>
/*
* @File:   rank.js
* @Author: Gxlcms
* @Email:  2010409646@qq.com
* @Date:   2020-7-10 23:17:59
* @Last Modified by:   Gxlcms
* @Last Modified time: 2020-7-10 10:48:49
* @Comment:
*/
import RankRequest from "../../requests/RankRequest";
var app = getApp();
var rankRequest = new RankRequest();

export default {
  data() {
    return {
      rank_categories: [],
      sex: 1,
      // 1男 2女
      male_select: "male_select",
      female_select: "",
      cover: "cover_male",
      user: {}
    };
  },

  components: {},
  props: {},
  onLoad: function () {
    uni.showLoading({
      "title": "加载中...",
      "duration": 20000
    });
    var user = uni.getStorageSync('user');
    this.setData({
      user
    });
    this.getRanks();
  },
  methods: {
    /**
     * 获取排行榜信息
     */
    getRanks: function () {
      var that = this;
      rankRequest.getRanks(this.sex, this.user, res => {
        that.setData({
          rank_categories: res.data.data.map(item => {
            item.title = item.name.split('.')[1];
            return item;
          })
        });
        uni.hideLoading();
      });
    },

    /**
     * 切换到男生
     */
    male_tap: function () {
      if (this.sex != 1) {
        this.setData({
          male_select: "male_select",
          female_select: "",
          cover: "cover_male",
          sex: 1
        });
        this.getRanks();
      }
    },

    /**
     * 切换到女生
     */
    female_tap: function () {
      if (this.sex != 2) {
        this.setData({
          male_select: "",
          female_select: "female_select",
          cover: "cover_female",
          sex: 2
        });
        this.getRanks();
      }
    }
  }
};
</script>
<style>
@import "./rank.css";
</style>