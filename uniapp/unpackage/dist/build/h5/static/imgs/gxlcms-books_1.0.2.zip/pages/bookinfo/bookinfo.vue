<template>
<view class="main">
	<view class="book_detail_box">
		<image :src="book_info.image" lazy-load></image>
		<view class="book_detail">
			<text class="book_title">{{book_info.name}}</text>
			<view class="book_author_title">作者：<navigator :url="'/pages/searchRes/searchRes?keyword=' + book_info.author" class="book_author">{{book_info.author}}</navigator></view>
			<text class="book_cate">类别：{{book_info.ltype}}　{{book_info.stype}}</text>
			<view class="rating_title">喜欢人数：
				<text class="rating_score" v-if="book_info.remark">{{book_info.fav_num}}</text>
				<text v-else>没人喜欢T^T</text>
			</view>
		</view>
	</view>
	<scroll-view class="other" scroll-y>
		<view class="other_box">
			<view class="other_title">简　介</view>
			<view class="other_content" v-if="book_info.remark">{{book_info.remark}}</view>
			<view class="other_content" v-else>暂无简介</view>
		</view>
		<view class="other_box">
			<view class="other_title">书源及最新章节</view>
			<view class="other_content">
				<view v-for="(item, index) in book_source_info" :key="index" class="book_source"><text style="color:black;">{{item.site_name}}</text>：{{item.last_chapter_name}}</view>
			</view>
		</view>
		<view class="other_box">
			<view class="other_title">作者书籍<text style="color:#cccccc;font-size:24rpx;"></text></view>
			<scroll-view scroll-x>
				<view  v-if="author_books.length>0">
					<navigator v-for="(item, index) in author_books" :key="index" :url="'/pages/bookinfo/bookinfo?book=' + item.book_id" class="related_book"> 
						<image :src="item.image"></image>
						<view class="related_book_title">{{item.name}}</view>
					</navigator>
				</view>
			  <view v-else class="result_tips">暂无其他书籍</view>
			</scroll-view>
		</view>
		<view class="other_box">
			<view class="other_title">热门评论</view>
			<view v-if="book_reviews.length>0">
				<view v-for="(item, index) in book_reviews" :key="index" class="other_content" style="border-bottom:1px solid #dddddd;display:flex;">
          <view style="flex:1">
            <view><image :src="item.avatar" class="avatar"></image></view>
            <!-- <view class="reviews_title">{{item.nick}}</view> -->
          </view>
					<view class="reviews_content">{{item.content}}</view>
				</view>
			</view>
			<view v-else class="result_tips">暂无评论</view>
		</view>
	</scroll-view>

	<view class="footer">
		<picker class="button" :value="index" range-key="site_name" :range="book_source_info" @change="changeSource">
	    	<view class="select_source">{{index<0 ?"选择书源":book_source_info[index].site_name}}</view>
  		</picker>
		<view :class="'button ' + add_to_mybooks_style" @tap="add_fun">{{add_book_stat}}</view>
		<view class="button start_read" @tap="startRead">开始阅读</view>
	</view>
</view>
</template>

<script>
/*
* @File:   bookinfo.js
* @Author: Gxlcms
* @Email:  2010409646@qq.com
* @Last Modified by:   Gxlcms
* @Comment:
*/
import BookRequest from "../../requests/BookRequest";
var bookRequest = new BookRequest();
var app = getApp();
export default {
  data() {
    return {
      book_info: {},
      book_source_info: [],
      // 书源
      author_books: [],
      // 作者其他书籍
      book_reviews: {},
      // 评论
      // select_source_tips: "选择书源",
      index: -1,
      source_id: "",
      mybooks: [],
      add_book_stat: "加入书架",
      add_to_mybooks_style: "add_to_mybooks",
      add_fun: "addToMybooks()",
      get_data_flag: 0,
      token: "",
      userId: ""
    };
  },

  components: {},
  props: {},
  onLoad: function (opt) {
    uni.showLoading({
      "title": "加载中...",
      "duration": 20000
    });
    var that = this;
    var bookId = opt.book;
    var userInfo = uni.getStorageSync('user');
    this.setData({
      token: userInfo.token,
      userId: userInfo.userId
    });
    bookRequest.getBookInfo(bookId, userInfo, res => {
      that.setData({
        book_info: res.data.data,
        book_source_info: res.data.data.sites,
        author_books: res.data.data.author_book_list,
        book_reviews: res.data.data.comment_info_list,
        get_data_flag: that.get_data_flag + 1
      });
      this.getMyBooks();
      if (this.get_data_flag == 2) uni.hideLoading();
    });
  },
  methods: {
    /**
     * 获取本地书架信息
     */
    getMyBooks: function () {
      var book_id = this.book_info.book_id;
      var mybooks = uni.getStorageSync("mybooks");
      mybooks = mybooks ? mybooks : [];
      this.setData({
        mybooks: mybooks,
        get_data_flag: this.get_data_flag + 1
      });
      if (this.get_data_flag == 2) uni.hideLoading();

      if (this.isInMybooks(mybooks, book_id) != -1) {
        var index = this.isInMybooks(mybooks, book_id);
        var source_id = this.mybooks[index].source_id;
        var source_index = this.indexOfSource(this.book_source_info, source_id);
        this.setData({
          index: source_index,
          source_id: source_id,
          add_book_stat: "已加入",
          add_to_mybooks_style: "added",
          add_fun: "removeBook()"
        });
      }
    },

    /**
     * 改变书源
     */
    changeSource: function (event) {
      var index = event.detail.value;
	  if(index==-1){
		  index=0
	  }
		console.log(index)
      this.setData({
        index: index,
        source_id: this.book_source_info[index].site
      });
    },

    /**
     * 添加到书架
     */
    addToMybooks: function (event) {
		
		console.log(event)
      if (this.source_id == "") {
        uni.showToast({
          title: "请先选择书源",
          icon: "none"
        });
      } else {
        var mybooks = this.mybooks;
        var need_add_book = {
          book_id: this.book_info.book_id,
          source_id: this.source_id,
          book_info: {
            name: this.book_info.name,
            image: this.book_info.image,
            author: this.book_info.author,
            ltype: this.book_info.ltype,
            stype: this.book_info.stype,
            remark: this.book_info.remark,
            last_chapter: this.book_info.last_chapter
          },
          reading_chapter: 0,
          reading_process: 0
        };

        if (this.isInMybooks(mybooks, need_add_book.book_id) == -1) {
          mybooks.push(need_add_book);

          try {
            uni.setStorageSync('mybooks', mybooks);
          } catch (e) {
            uni.showToast({
              title: "未知错误，稍后再试",
              icon: "none"
            });
          }

          this.setData({
            mybooks: mybooks,
            add_book_stat: "已加入",
            add_to_mybooks_style: "added",
            add_fun: "removeBook()"
          });
          uni.showToast({
            title: "已添加至书架",
            icon: "success"
          });
        }
      }
    },

    /**
     * 移出书架
     */
    removeBook: function (event) {
      uni.showToast({
        title: '请前往"书架"移除',
        icon: "none"
      }); // var that = this;
      // uni.showModal({
      //   title: '是否移出书架？',
      //   content: '将会删除该书的阅读记录',
      //   success: function(res) {
      //     if(res.confirm){
      //       	var book_id = that.data.book_info._id;
      // 		try {
      // 	      var mybooks = uni.getStorageSync("mybooks");
      // 	    } catch (e) {
      // 	      uni.showToast({
      // 	        title: "未知错误，稍后再试",
      // 	        icon: "none"
      // 	      });
      // 	    }
      // 		var index = that.isInMybooks(mybooks, book_id);
      // 		mybooks.splice(index, 1);
      // 		try{
      // 			uni.setStorageSync('mybooks', mybooks);
      // 		}catch(e){
      // 			uni.showToast({
      // 				title: "未知错误，稍后再试",
      // 				icon: "none"
      // 			});
      // 		}
      // 		that.setData({
      // 			mybooks: mybooks,
      // 			add_book_stat: "加入书架",
      // 			add_to_mybooks_style: "add_to_mybooks",
      // 			add_fun: "addToMybooks"
      // 		});
      // 		uni.showToast({
      // 			title: "已从书架移除",
      // 			icon: "none"
      // 		});
      //     }else if(res.cancel){
      //     }
      //   }
      // });
    },

    /**
     * 开始阅读
     */
    startRead: function (event) {
      if (this.source_id == "") {
        uni.showToast({
          title: "请先选择书源",
          icon: "none"
        });
      } else {
        uni.navigateTo({
          url: "/pages/read/read?source_id=" + this.source_id + "&book_id=" + this.book_info.book_id
        });
      }
    },

    /**
     * 是否在我的书架
     */
    isInMybooks: function (arr, value) {
      var len = arr.length;

      for (var i = 0; i < len; i++) {
        if (value === arr[i].book_id) {
          return i;
        }
      }

      return -1;
    },

    /**
     * 获取资源index
     */
    indexOfSource: function (arr, value) {
      var len = arr.length;

      for (var i = 0; i < len; i++) {
        if (value === arr[i].site) {
          return i;
        }
      }

      return -1;
    }
  }
};
</script>
<style>
@import "./bookinfo.css";
</style>