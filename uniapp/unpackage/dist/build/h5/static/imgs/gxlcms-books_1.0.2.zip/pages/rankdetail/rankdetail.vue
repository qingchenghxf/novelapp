<template>
<view class="main">
  <view class="cat_choose">
		<view :class="'week ' + week_select" >周排行</view>
		<view :class="'month ' + month_select">月排行</view>
    <view :class="'all ' + all_select" >总排行</view>
		<view :class="'cover ' + cover"></view>
	</view>
	<scroll-view class="rank_books" scroll-y >
		
		<view class="loading">开发中...</view>
	</scroll-view>
</view>
</template>

<script>
/*
* @File:   rank_detail.js
* @Author: Gxlcms
* @Email:  2010409646@qq.com
* @Date:   2020-7-10 09:10:29
* @Last Modified by:   Gxlcms
* @Last Modified time: 2020-7-10 10:24:07
* @Comment:
*/


export default {
  data() {
    return {
      rank_id: "",
      rank_info: [],
      subType: 1,
      week_select: "week_select",
      month_select: "",
      all_select: "",
      cover: "cover_week",
      show_num: 1,
      user: ""
    };
  },

  components: {},
  props: {},
  onLoad: function (opt) {
   
  },
  methods: {
  
  }
};
</script>
<style>
@import "./rankdetail.css";
</style>