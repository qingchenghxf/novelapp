<template>
<view class="main" >
	开发中
</view>
</template>

<script>
/*
* @File:   searchRes.js
* @Author: Gxlcms
* @Email:  2010409646@qq.com
* @Date:   2018-02-20 18:08:28
* @Last Modified by:   Gxlcms
* @Last Modified time: 2020-7-10 21:32:32
* @Comment:
*/
import IndexRequest from "../../requests/IndexRequest";
import SearchRequest from "../../requests/SearchRequest";

export default {
  data() {
    return {
      scroll_sta: true,
      search_result: [],
      auto_complete_box: "auto_complete_box auto_complete_box_hidden",
      last_keyword: "",
      keyword: "",
      keywords: [],
      result_tips: "",
      page: 1,
      token: "",
      userId: 0
    };
  },



  /**
   * 加载完钩子
   */
  onLoad: function (opt) {
  
  },
  methods: {
   
  }
};
</script>
<style>
@import "./searchRes.css";
</style>