<template>
<view :class="'main main_font_style_' + (button_select[1]+button_select[2]*2)">
	<scroll-view class="chapter_content"  @scroll="setReadingProcess" @tap="changeCover"  scroll-y="true" :scroll-top="scrollTop">
		<view class="title"><text>{{chapter_title}}</text></view>
		<view :class="'body body_font_size_' + font_size + ' body_font_size_' + (font_size*3+line_height) + '_line_height'">
			<text decode=true>{{"&emsp;&emsp;"+chapter_content}}</text>
		</view>
		<view class="jump_chapter" :style="'opacity:' + opacity + ';'">
			<view :class="'pre_chapter ' + (reading_chapter?'enabled':'disabled')" @tap.stop="reading_chapter?toPreChapter():setPreButtonDisabled()">上一章</view>
			<view :class="'next_chapter ' + (reading_chapter == book_chapters.length-1?'disabled':'enabled')" @tap.stop="reading_chapter==book_chapters.length-1?setNextButtonDisabled():toNextChapter()">下一章</view>
		</view>
	</scroll-view>
	<view :class="'cover ' + cover_style">
		<view class="read_style">
			<view :class="'button ' + (button_select[0]?'button_select':'')" @tap="changeStyle" data-id="0">日间</view>
			<view :class="'button ' + (button_select[1]?'button_select':'')" @tap="changeStyle" data-id="1">护眼</view>
			<view :class="'button ' + (button_select[2]?'button_select':'')" @tap="changeStyle" data-id="2">夜间</view>
		</view>
		<view class="read_style">
			<view :class="'button ' + (font_size==0?'button_disabled':'button_enabled')" @tap="font_size==0?'none':font_size_sub()">Aa-</view>
			<view :class="'button ' + (font_size==4?'button_disabled':'button_enabled')" @tap="font_size==4?'none':font_size_add()">Aa+</view>
		</view>
		<view class="read_style">
			<view :class="'button ' + (line_height==0?'button_disabled':'button_enabled')" @tap="line_height==0?'none':line_height_sub()">行距-</view>
			<view :class="'button ' + (line_height==2?'button_disabled':'button_enabled')" @tap="line_height==2?'none':line_height_add()">行距+</view>
		</view>
		<view class="read_style">
			<picker :range="book_source_info" range-key="site_name" :value="index_source" class="button" @change="changeSource">换源</picker>
			<view class="button" @tap="showChapters">目录</view>
			<view class="button" @tap="toBookInfo">详情</view>
		</view>
	</view>
	<view :class="'chapters ' + chapters_style">
		<view class="chapters_title">目录</view>
		<view class="chapters_content">
		<scroll-view style="height:100%;" scroll-y :scroll-into-view="'chapter' + (to_reading_chapter-5)" scroll-with-animation>
			<!-- <view> -->
				<view v-for="(item, index) in book_chapters" :key="index" :class="'chapter ' + (index==reading_chapter?'chapter_select':'')" :data-index="index" @tap="toObjChapter" :id="'chapter' + index">{{item.name}}</view>
			<!-- </view> -->
		</scroll-view>
		</view>
	</view>
</view>
</template>

<script>
/*
* @File:   read.js
* @Author: Alan_Albert
* @Email:  1766447919@qq.com
* @Date:   2018-02-22 08:48:49
* @Last Modified by:   Alan_Albert
* @Last Modified time: 2018-02-25 18:22:16
* @Comment:
*/
import ReadRequest from "../../requests/ReadRequest";
var app = getApp();
var readRequest = new ReadRequest();

export default {
  data() {
    return {
      source_id: "",
      book_id: "",
      mybooks: new Array(),
      book_chapters: [],
	  scrollTop:0,
      reading_chapter: 0,
      reading_process: 0,
      chapter_title: "",
      chapter_content: "",
      opacity: 0,
      cover_style: "cover_hide",
      chapters_style: "chapters_hide",
      to_reading_chapter: 0,
      book_source_info: [],
      book_source_name: [],
      index_source: 0,
      button_select: {
        0: 1,
        1: 0,
        2: 0
      },
      font_size: 2,
      line_height: 1,
      user: {}
    };
  },

  components: {},
  props: {},
  onLoad: function (opt) {
    var user = uni.getStorageSync('user');
	
	this.user=user;
    this.loading(opt.book_id, opt.source_id);
  },

  /**
   * 小程序隐藏回调
   */
  onHide: function () {
    var mybooks = this.mybooks;
    var index = this.isInMybooks(mybooks, this.book_id);

    if (index != -1) {
      mybooks[index].reading_process = this.reading_process;
      mybooks[index].reading_chapter = this.reading_chapter;

      try {
        uni.setStorageSync('mybooks', mybooks);
      } catch (e) {
        uni.showToast({
          title: "未知错误，稍后再试",
          icon: "none"
        });
      }
    }
  },

  /**
   * 回调
   */
  onUnload: function () {
    var mybooks = this.mybooks;
    var index = this.isInMybooks(mybooks, this.book_id);

    if (index != -1) {
      mybooks[index].reading_process = this.reading_process;
      mybooks[index].reading_chapter = this.reading_chapter;

      try {
        uni.setStorageSync('mybooks', mybooks);
      } catch (e) {
        uni.showToast({
          title: "未知错误，稍后再试",
          icon: "none"
        });
      }
    }
  },
  methods: {
    /**
     * 加载中
     */
    loading: function (bookId, sourceId) {
      uni.showLoading({
        "title": "加载中...",
        "duration": 20000
      });
     
	  this.source_id=sourceId;
	  this.book_id=bookId;
      this.getBookChapters(bookId, sourceId);
      this.getBookSource(bookId);
      this.getStyleStorage();
    },

    /**
     * 获取书籍章节
     */
    getBookChapters: function (bookId, sourceId) {
      var that = this;
      readRequest.getChapters(bookId, sourceId, this.user, res => {
        var reading_chapter = that.getReadingChapter();
     
		that.book_chapters=res.data.data
		that.chapter_title=res.data.data[reading_chapter].name
        uni.setNavigationBarTitle({
          title: res.data.data[reading_chapter].name
        });
        that.getChapterContent(that.book_chapters[reading_chapter].chapter_id, that.book_chapters[reading_chapter].crawl_book_id, that.book_chapters[reading_chapter].lists_id, sourceId,1);
      });
    },

    /**
     * 获取正在阅读的章节
     */
    getReadingChapter: function () {
      var book_id = this.book_id;
      var mybooks = uni.getStorageSync("mybooks");
      var index = this.isInMybooks(mybooks, book_id);
      var chapter_index = 0;
      var reading_process = 0;

      if (index != -1) {
        chapter_index = mybooks[index].reading_chapter;
        reading_process = mybooks[index].reading_process;
      }

     
	  this.mybooks=mybooks;
	  this.reading_chapter=chapter_index;
	  this.reading_process=reading_process;
      return chapter_index;
    },

    /**
     * 获取章节内容
     */
    getChapterContent: function (chapterId, sourceBookId, listsId, sourceId,is) {
      var that = this;
      readRequest.getChapterContent(chapterId, sourceBookId, listsId, sourceId, this.user, res => {
      
		res.data.data.content=res.data.data.content.replace(/\n/g,"\n &emsp;&emsp;");
		this.chapter_content=res.data.data.content
	
		that.opacity= 1
        uni.hideLoading();
	 if(is==1){
		 
		 this.scrollTop=0
		 this.scrollTop=Math.random();
	 }
		
        if (that.reading_process) {
          uni.showModal({
            title: "跳转到上次阅读的位置？",
            success: res => {
              if (res.confirm) {
			
				
              } else if (res.cancel) {
               
				that.reading_process=0
              }
            }
          });
        }
      });
	  
    },

    /**
     * 是否在我的书架
     */
    isInMybooks: function (arr, value) {
      var len = arr.length;

      for (var i = 0; i < len; i++) {
        if (value == arr[i].book_id) {
          return i;
        }
      }

      return -1;
    },

    /**
     * 设置阅读进度
     */
    setReadingProcess: function (event) {
   
	  this.reading_process=event.detail.scrollTop;
	  
	
    },

    /**
     * disable上一章
     */
    setPreButtonDisabled: function () {
      uni.showToast({
        title: "已经是第一章",
        icon: "none"
      });
    },

    /**
     * disable下一章
     */
    setNextButtonDisabled: function () {
      uni.showToast({
        title: "已经是最后一章",
        icon: "none"
      });
    },

    /**
     * 跳转到前一章
     */
    toPreChapter: function () {
      var reading_chapter = this.reading_chapter - 1;
      this.toChapter(reading_chapter);
    },

    /**
     * 跳转到后一章
     */
    toNextChapter: function () {
      var reading_chapter = this.reading_chapter + 1;
      this.toChapter(reading_chapter);
    },

    /**
     * 跳转章节
     */
    toChapter: function (reading_chapter) {
      uni.showLoading({
        "title": "加载中...",
        "duration": 20000
      });
      var title = this.book_chapters[reading_chapter].name;
   
	   this.reading_chapter=reading_chapter;
	   this.reading_process=0;
	
	   
	 this.chapter_title=title;
      uni.setNavigationBarTitle({
        title: title
      });
	  //滚动位置
	 

      this.getChapterContent(this.book_chapters[reading_chapter].chapter_id, this.book_chapters[reading_chapter].crawl_book_id, this.book_chapters[reading_chapter].lists_id, this.source_id,1);
    },

    /**
     * 改变蒙层
     */
    changeCover: function () {
      var cover_style = this.cover_style;
      var chapters_style = this.chapters_style;
      if (chapters_style == "chapters_show") chapters_style = "chapters_hide";else if (cover_style == "cover_hide") cover_style = "cover_show";else cover_style = "cover_hide";
	  
	  this.cover_style=cover_style;
	  this.chapters_style=chapters_style;
     
    },

    /**
     * 跳转到书籍详情
     */
    toBookInfo: function () {
      uni.navigateTo({
        url: "/pages/bookinfo/bookinfo?book=" + this.book_id
      });
    },

    /**
     * 跳转到目标章节
     */
    toObjChapter: function (event) {
      var chapter_index = event.currentTarget.dataset.index;
      this.toChapter(chapter_index);
    },

    /**
     * 显示章节信息
     */
    showChapters: function () {
      var to_reading_chapter = this.reading_chapter;
   
	  this.cover_style="cover_hide";
	  this.to_reading_chapter=to_reading_chapter;
	  this.chapters_style="chapters_show";
    },

    /**
     * 获取书源信息
     */
    getBookSource: function (book_id) {
      var that = this;
      readRequest.getSources(book_id, this.user, res => {
        var index_source = that.indexOfSource(res.data, that.source_id);
    
		this.book_source_info=res.data.data
		this.book_source_name=res.data.data.map(item => item.site_name)
		this.index_source=index_source
      });
    },

    /**
     * 获取资源index
     */
    indexOfSource: function (arr, value) {
      var len = arr.length;

      for (var i = 0; i < len; i++) {
        if (value === arr[i].site) {
          return i;
        }
      }

      return -1;
    },

    /**
     * 修改书源
     */
    changeSource: function (event) {
      var that = this;
      var source_index = event.detail.value;
      uni.showModal({
        title: "确认换源？",
        content: "可能造成阅读记录发生偏差",
        success: function (res) {
          if (res.confirm) {
          
			this.source_id=that.book_source_info[source_index].site;
			this.index_source=source_index;
            var mybooks = that.mybooks;
            var index = that.isInMybooks(mybooks, that.book_id);

            if (index != -1) {
              mybooks[index].reading_chapter = that.reading_chapter;
              mybooks[index].source_id = that.source_id;

              try {
                uni.setStorageSync('mybooks', mybooks);
              } catch (e) {
                uni.showToast({
                  title: "未知错误，稍后再试",
                  icon: "none"
                });
              }
            }

            uni.redirectTo({
              url: "/pages/read/read?source_id=" + that.source_id + "&book_id=" + that.book_id
            });
          } else if (res.cancel) {
         
			this.index_source=source_index;
          }
        }
      });
    },

    /**
     * 改变样式
     */
    changeStyle: function (event) {
      var style_id = event.target.dataset.id;
      var button_select = {
        0: 1,
        1: 0,
        2: 0
      };

      if (style_id == 1) {
        button_select = {
          0: 0,
          1: 1,
          2: 0
        };
      } else if (style_id == 2) {
        button_select = {
          0: 0,
          1: 0,
          2: 1
        };
      }

     
	  this.button_select=button_select; 
      this.setStyleStorage();
    },

    /**
     * 减小字体
     */
    font_size_sub: function () {
     this.font_size= this.font_size - 1
     
      this.setStyleStorage();
    },

    /**
     * 增大字体
     */
    font_size_add: function () {
      this.font_size= this.font_size + 1
	  console.log('+++')
      this.setStyleStorage();
    },

    /**
     * 减小行高
     */
    line_height_sub: function () {
   this.line_height=this.line_height - 1
      this.setStyleStorage();
    },

    /**
     * 增大行高
     */
    line_height_add: function () {
      
	  this.line_height=this.line_height + 1
      this.setStyleStorage();
    },

    /**
     * 获取本地样式
     */
    getStyleStorage: function () {
      var style = uni.getStorageSync("style");

      if (style) {
		  this.button_select=style.button_select
		   this.font_size=style.font_size
		    this.line_height=style.line_height
   
      }
    },

    /**
     * 保存样式到本地
     */
    setStyleStorage: function () {
      var style = {
        button_select: this.button_select,
        font_size: this.font_size,
        line_height: this.line_height
      };

      try {
        uni.setStorageSync('style', style);
      } catch (e) {
        uni.showToast({
          title: "未知错误，稍后再试",
          icon: "none"
        });
      }
    },
    none: function () {}
  }
};
</script>
<style>
@import "./read.css";
</style>