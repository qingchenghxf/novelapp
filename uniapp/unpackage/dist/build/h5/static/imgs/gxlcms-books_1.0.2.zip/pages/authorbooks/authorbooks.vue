<template>
<view class="main">
	<navigator v-for="(item, index) in author_books" :key="index" :url="'/pages/bookinfo/bookinfo?book=' + item._id" class="book">
		<image :src="'https://statics.zhuishushenqi.com' + item.cover" lazy-load></image>
		<view class="book_info">
			<text class="title">{{item.title}}</text>
			<text class="author">作者：{{item.author}} | 类别：{{item.majorCate}}　{{item.minorCate}}</text>
			<text class="intro">简介：{{item.shortIntro}}</text>
			<view class="follower_outter">人气：<text class="follower_inner">{{item.latelyFollower}}</text></view>
		</view>
	</navigator>
</view>
</template>

<script>
/*
* @File:   authorbooks.js
* @Author: Gxlcms
* @Email:  2010409646@qq.com
* @Date:   2020-7-10 14:54:27
* @Last Modified by:   Gxlcms
* @Last Modified time: 2020-7-10 23:16:20
* @Comment:
*/
var app = getApp();

export default {
  data() {
    return {
      author: "",
      author_books: {}
    };
  },

  components: {},
  props: {},
  onLoad: function (opt) {
    uni.showLoading({
      "title": "加载中...",
      "duration": 20000
    }); // console.log(opt);

    this.setData({
      author: opt.author
    });
    uni.setNavigationBarTitle({
      title: this.author
    });
    this.getAuthorBooks();
  },
  methods: {
    getAuthorBooks: function () {
      var that = this;
      var author = encodeURI(this.author);
      var url = app.globalData.config.book.author_books + "?author=" + author;
      uni.request({
        url: url,
        success: function (res) {
          that.setData({
            author_books: res.data.books
          }); // console.log(that.data.author_books);

          uni.hideLoading();
        },
        fail: function () {
          uni.hideLoading();
          uni.showModal({
            title: "网络错误，请稍后再试~"
          });
        }
      });
    }
  }
};
</script>
<style>
@import "./authorbooks.css";
</style>