import BaseRequest from "./BaseRequest";
var app = getApp();

class SearchRequest extends BaseRequest {
  /**
   * 获取搜索书籍
   */
  

}

export default SearchRequest;